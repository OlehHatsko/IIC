create unique index USER_LOGIN_UINDEX
    on USER (LOGIN);

