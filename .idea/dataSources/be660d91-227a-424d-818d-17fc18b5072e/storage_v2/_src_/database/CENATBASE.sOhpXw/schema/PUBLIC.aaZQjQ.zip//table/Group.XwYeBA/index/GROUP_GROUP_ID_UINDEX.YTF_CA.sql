create unique index GROUP_GROUP_ID_UINDEX
    on "Group" (GROUP_ID);

